package org.Proyecto.ACT5_Santiago.pokemon;

public enum Rareza {
    COMUN,
    RARO,
    LEGENDARIO
}
