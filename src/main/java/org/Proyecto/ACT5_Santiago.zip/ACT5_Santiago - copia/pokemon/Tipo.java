package org.Proyecto.ACT5_Santiago.pokemon;

public enum Tipo {
    FUEGO,
    AGUA,
    PLANTA,
    ELECTRICO,
    HIELO,
    LUCHA,
    VENENO,
    TIERRA,
    VOLADOR,
    PSIQUICO,
    BICHO,
    ROCA,
    FANTASMA,
    DRAGON,
    SINIESTRO,
    ACERO,
    HADA,
    NORMAL
}
